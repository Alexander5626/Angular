import { Component } from '@angular/core';

@Component({
  selector: 'app-navi',
  standalone: true,
  imports: [],
  templateUrl: './navi.component.html',
  styleUrl: './navi.component.css'
})
export class NaviComponent {

}
